--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.10
-- Dumped by pg_dump version 9.5.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.remarks DROP CONSTRAINT fk_rails_fa0cd92a53;
ALTER TABLE ONLY public.master_exports DROP CONSTRAINT fk_rails_f50eebf7d7;
ALTER TABLE ONLY public.user_trackings DROP CONSTRAINT fk_rails_efe233af29;
ALTER TABLE ONLY public.truck_heads DROP CONSTRAINT fk_rails_ee027e25bf;
ALTER TABLE ONLY public.container_groups DROP CONSTRAINT fk_rails_de5a88ae1a;
ALTER TABLE ONLY public.company_tiers DROP CONSTRAINT fk_rails_de593c7900;
ALTER TABLE ONLY public.remarks DROP CONSTRAINT fk_rails_dd1ea8a239;
ALTER TABLE ONLY public.noti_truckers DROP CONSTRAINT fk_rails_d07f33023c;
ALTER TABLE ONLY public.dangerous_classes DROP CONSTRAINT fk_rails_ce936c5075;
ALTER TABLE ONLY public.transportation_assignments DROP CONSTRAINT fk_rails_cb06650eb5;
ALTER TABLE ONLY public.container_groups DROP CONSTRAINT fk_rails_c6595a9f62;
ALTER TABLE ONLY public.remarks DROP CONSTRAINT fk_rails_be53cc8828;
ALTER TABLE ONLY public.notifications DROP CONSTRAINT fk_rails_b080fb4855;
ALTER TABLE ONLY public.transportations DROP CONSTRAINT fk_rails_af04ab7590;
ALTER TABLE ONLY public.assignments DROP CONSTRAINT fk_rails_aa6b76dac2;
ALTER TABLE ONLY public.transportations DROP CONSTRAINT fk_rails_a21139870a;
ALTER TABLE ONLY public.assignments DROP CONSTRAINT fk_rails_9e2526b1f7;
ALTER TABLE ONLY public.trailers DROP CONSTRAINT fk_rails_969bd1d1e2;
ALTER TABLE ONLY public.transportation_assignments DROP CONSTRAINT fk_rails_863f95b586;
ALTER TABLE ONLY public.company_tiers DROP CONSTRAINT fk_rails_7fa458e19f;
ALTER TABLE ONLY public.bid_fors DROP CONSTRAINT fk_rails_7a06624a86;
ALTER TABLE ONLY public.users DROP CONSTRAINT fk_rails_7682a3bdfe;
ALTER TABLE ONLY public.journeys DROP CONSTRAINT fk_rails_607ab95c36;
ALTER TABLE ONLY public.transportation_assignments DROP CONSTRAINT fk_rails_5f7846a331;
ALTER TABLE ONLY public.assignments DROP CONSTRAINT fk_rails_5a1b4dd1a9;
ALTER TABLE ONLY public.bid_fors DROP CONSTRAINT fk_rails_451c40309f;
ALTER TABLE ONLY public.containers DROP CONSTRAINT fk_rails_36401535f0;
ALTER TABLE ONLY public.noti_truckers DROP CONSTRAINT fk_rails_34f548048f;
ALTER TABLE ONLY public.documents DROP CONSTRAINT fk_rails_2be0318c46;
ALTER TABLE ONLY public.transportation_assignments DROP CONSTRAINT fk_rails_2492f05953;
ALTER TABLE ONLY public.documents DROP CONSTRAINT fk_rails_20a77c438c;
ALTER TABLE ONLY public.transportations DROP CONSTRAINT fk_rails_0f807e0752;
ALTER TABLE ONLY public.transportations DROP CONSTRAINT fk_rails_018e0f79f5;
DROP INDEX public.mov_index1;
DROP INDEX public.index_work_orders_on_slug;
DROP INDEX public.index_users_on_slug;
DROP INDEX public.index_users_on_company_id;
DROP INDEX public.index_user_trackings_on_user_id;
DROP INDEX public.index_truck_heads_on_company_id;
DROP INDEX public.index_transportations_on_work_order_id;
DROP INDEX public.index_transportations_on_journey_id;
DROP INDEX public.index_transportations_on_container_id;
DROP INDEX public.index_transportations_on_company_id;
DROP INDEX public.index_transportation_assignments_on_user_id;
DROP INDEX public.index_transportation_assignments_on_truck_head_id;
DROP INDEX public.index_transportation_assignments_on_transportation_id;
DROP INDEX public.index_transportation_assignments_on_trailer_id;
DROP INDEX public.index_trailers_on_company_id;
DROP INDEX public.index_remarks_on_work_order_id;
DROP INDEX public.index_remarks_on_user_id;
DROP INDEX public.index_remarks_on_company_id;
DROP INDEX public.index_notifications_on_user_id;
DROP INDEX public.index_noti_truckers_on_notification_id;
DROP INDEX public.index_noti_truckers_on_company_id;
DROP INDEX public.index_movement_events_on_cnt_number;
DROP INDEX public.index_movement_events_on_cnt_movement_status_code;
DROP INDEX public.index_master_exports_on_file_upload_id;
DROP INDEX public.index_master_exports_on_created_by_id;
DROP INDEX public.index_journeys_on_work_order_id;
DROP INDEX public.index_friendly_id_slugs_on_sluggable_type;
DROP INDEX public.index_friendly_id_slugs_on_sluggable_id;
DROP INDEX public.index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope;
DROP INDEX public.index_friendly_id_slugs_on_slug_and_sluggable_type;
DROP INDEX public.index_event_lists_on_work_order_number;
DROP INDEX public.index_event_details_on_event_list_id;
DROP INDEX public.index_documents_on_work_order_id;
DROP INDEX public.index_documents_on_user_id;
DROP INDEX public.index_dangerous_classes_on_container_id;
DROP INDEX public.index_daily_assignments_on_confirm_token;
DROP INDEX public.index_containers_on_work_order_id;
DROP INDEX public.index_containers_on_mode;
DROP INDEX public.index_container_groups_on_work_order_id;
DROP INDEX public.index_container_groups_on_carrier_quotation_id;
DROP INDEX public.index_company_tiers_on_tier_id;
DROP INDEX public.index_company_tiers_on_company_id;
DROP INDEX public.index_companies_on_slug;
DROP INDEX public.index_booking_cargos_on_container_number;
DROP INDEX public.index_bid_fors_on_work_order_id;
DROP INDEX public.index_bid_fors_on_company_id;
DROP INDEX public.index_assignments_on_work_order_id;
DROP INDEX public.index_assignments_on_user_id;
DROP INDEX public.index_assignments_on_company_id;
DROP INDEX public.delayed_jobs_priority;
ALTER TABLE ONLY public.work_orders DROP CONSTRAINT work_orders_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.user_trackings DROP CONSTRAINT user_trackings_pkey;
ALTER TABLE ONLY public.user_restrictions DROP CONSTRAINT user_restrictions_pkey;
ALTER TABLE ONLY public.truck_heads DROP CONSTRAINT truck_heads_pkey;
ALTER TABLE ONLY public.transportations DROP CONSTRAINT transportations_pkey;
ALTER TABLE ONLY public.transportation_assignments DROP CONSTRAINT transportation_assignments_pkey;
ALTER TABLE ONLY public.trailers DROP CONSTRAINT trailers_pkey;
ALTER TABLE ONLY public.tracking_imports DROP CONSTRAINT tracking_imports_pkey;
ALTER TABLE ONLY public.tiers DROP CONSTRAINT tiers_pkey;
ALTER TABLE ONLY public.terms DROP CONSTRAINT terms_pkey;
ALTER TABLE ONLY public.temporaries DROP CONSTRAINT temporaries_pkey;
ALTER TABLE ONLY public.supports DROP CONSTRAINT supports_pkey;
ALTER TABLE ONLY public.shipper_payments DROP CONSTRAINT shipper_payments_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.restrictions DROP CONSTRAINT restrictions_pkey;
ALTER TABLE ONLY public.remarks DROP CONSTRAINT remarks_pkey;
ALTER TABLE ONLY public.rails_allocations DROP CONSTRAINT rails_allocations_pkey;
ALTER TABLE ONLY public.psa_groups DROP CONSTRAINT psa_groups_pkey;
ALTER TABLE ONLY public.priorities DROP CONSTRAINT priorities_pkey;
ALTER TABLE ONLY public.portnets DROP CONSTRAINT portnets_pkey;
ALTER TABLE ONLY public.permits DROP CONSTRAINT permits_pkey;
ALTER TABLE ONLY public.performance_reports DROP CONSTRAINT performance_reports_pkey;
ALTER TABLE ONLY public.outloads DROP CONSTRAINT outloads_pkey;
ALTER TABLE ONLY public.notifications DROP CONSTRAINT notifications_pkey;
ALTER TABLE ONLY public.noti_truckers DROP CONSTRAINT noti_truckers_pkey;
ALTER TABLE ONLY public.movement_events DROP CONSTRAINT movement_events_pkey;
ALTER TABLE ONLY public.master_exports DROP CONSTRAINT master_exports_pkey;
ALTER TABLE ONLY public.locations DROP CONSTRAINT locations_pkey;
ALTER TABLE ONLY public.journeys DROP CONSTRAINT journeys_pkey;
ALTER TABLE ONLY public.indischarges DROP CONSTRAINT indischarges_pkey;
ALTER TABLE ONLY public.import_files DROP CONSTRAINT import_files_pkey;
ALTER TABLE ONLY public.group_permissions DROP CONSTRAINT group_permissions_pkey;
ALTER TABLE ONLY public.friendly_id_slugs DROP CONSTRAINT friendly_id_slugs_pkey;
ALTER TABLE ONLY public.file_uploads DROP CONSTRAINT file_uploads_pkey;
ALTER TABLE ONLY public.event_lists DROP CONSTRAINT event_lists_pkey;
ALTER TABLE ONLY public.event_details DROP CONSTRAINT event_details_pkey;
ALTER TABLE ONLY public.error_reports DROP CONSTRAINT error_reports_pkey;
ALTER TABLE ONLY public.documents DROP CONSTRAINT documents_pkey;
ALTER TABLE ONLY public.delayed_jobs DROP CONSTRAINT delayed_jobs_pkey;
ALTER TABLE ONLY public.delayed_allocations DROP CONSTRAINT delayed_allocations_pkey;
ALTER TABLE ONLY public.dangerous_classes DROP CONSTRAINT dangerous_classes_pkey;
ALTER TABLE ONLY public.daily_assignments DROP CONSTRAINT daily_assignments_pkey;
ALTER TABLE ONLY public.currencies DROP CONSTRAINT currencies_pkey;
ALTER TABLE ONLY public.containers DROP CONSTRAINT containers_pkey;
ALTER TABLE ONLY public.container_types DROP CONSTRAINT container_types_pkey;
ALTER TABLE ONLY public.container_psas DROP CONSTRAINT container_psas_pkey;
ALTER TABLE ONLY public.container_groups DROP CONSTRAINT container_groups_pkey;
ALTER TABLE ONLY public.container_details DROP CONSTRAINT container_details_pkey;
ALTER TABLE ONLY public.company_tiers DROP CONSTRAINT company_tiers_pkey;
ALTER TABLE ONLY public.companies DROP CONSTRAINT companies_pkey;
ALTER TABLE ONLY public.collect_times DROP CONSTRAINT collect_times_pkey;
ALTER TABLE ONLY public.carrier_quotations DROP CONSTRAINT carrier_quotations_pkey;
ALTER TABLE ONLY public.carrier_payments DROP CONSTRAINT carrier_payments_pkey;
ALTER TABLE ONLY public.carrier_assignments DROP CONSTRAINT carrier_assignments_pkey;
ALTER TABLE ONLY public.booking_orders DROP CONSTRAINT booking_orders_pkey;
ALTER TABLE ONLY public.booking_cargos DROP CONSTRAINT booking_cargos_pkey;
ALTER TABLE ONLY public.bid_fors DROP CONSTRAINT bid_fors_pkey;
ALTER TABLE ONLY public.assignments DROP CONSTRAINT assignments_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY public.allocation_assignment_groups DROP CONSTRAINT allocation_assignment_groups_pkey;
ALTER TABLE public.work_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_trackings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_restrictions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.truck_heads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transportations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transportation_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.trailers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tracking_imports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tiers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.terms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.temporaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.supports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.shipper_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.restrictions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.remarks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.rails_allocations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.psa_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.priorities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.portnets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.permits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.performance_reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.outloads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.noti_truckers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.movement_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.master_exports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.locations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.journeys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.indischarges ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.import_files ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.friendly_id_slugs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.file_uploads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.event_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.event_details ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.error_reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.delayed_jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.delayed_allocations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dangerous_classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.daily_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.currencies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.containers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.container_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.container_psas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.container_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.container_details ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.company_tiers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.collect_times ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.carrier_quotations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.carrier_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.carrier_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.booking_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.booking_cargos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bid_fors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.allocation_assignment_groups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.work_orders_id_seq;
DROP TABLE public.work_orders;
DROP VIEW public.view_last_movements;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.user_trackings_id_seq;
DROP TABLE public.user_trackings;
DROP SEQUENCE public.user_restrictions_id_seq;
DROP TABLE public.user_restrictions;
DROP SEQUENCE public.truck_heads_id_seq;
DROP TABLE public.truck_heads;
DROP SEQUENCE public.transportations_id_seq;
DROP TABLE public.transportations;
DROP SEQUENCE public.transportation_assignments_id_seq;
DROP TABLE public.transportation_assignments;
DROP SEQUENCE public.trailers_id_seq;
DROP TABLE public.trailers;
DROP SEQUENCE public.tracking_imports_id_seq;
DROP TABLE public.tracking_imports;
DROP SEQUENCE public.tiers_id_seq;
DROP TABLE public.tiers;
DROP SEQUENCE public.terms_id_seq;
DROP TABLE public.terms;
DROP SEQUENCE public.temporaries_id_seq;
DROP TABLE public.temporaries;
DROP SEQUENCE public.supports_id_seq;
DROP TABLE public.supports;
DROP SEQUENCE public.shipper_payments_id_seq;
DROP TABLE public.shipper_payments;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.restrictions_id_seq;
DROP TABLE public.restrictions;
DROP SEQUENCE public.remarks_id_seq;
DROP TABLE public.remarks;
DROP SEQUENCE public.rails_allocations_id_seq;
DROP TABLE public.rails_allocations;
DROP SEQUENCE public.psa_groups_id_seq;
DROP TABLE public.psa_groups;
DROP SEQUENCE public.priorities_id_seq;
DROP TABLE public.priorities;
DROP SEQUENCE public.portnets_id_seq;
DROP TABLE public.portnets;
DROP SEQUENCE public.permits_id_seq;
DROP TABLE public.permits;
DROP SEQUENCE public.performance_reports_id_seq;
DROP TABLE public.performance_reports;
DROP SEQUENCE public.outloads_id_seq;
DROP TABLE public.outloads;
DROP SEQUENCE public.notifications_id_seq;
DROP TABLE public.notifications;
DROP SEQUENCE public.noti_truckers_id_seq;
DROP TABLE public.noti_truckers;
DROP SEQUENCE public.movement_events_id_seq;
DROP TABLE public.movement_events;
DROP SEQUENCE public.master_exports_id_seq;
DROP TABLE public.master_exports;
DROP SEQUENCE public.locations_id_seq;
DROP TABLE public.locations;
DROP SEQUENCE public.journeys_id_seq;
DROP TABLE public.journeys;
DROP SEQUENCE public.indischarges_id_seq;
DROP TABLE public.indischarges;
DROP SEQUENCE public.import_files_id_seq;
DROP TABLE public.import_files;
DROP SEQUENCE public.group_permissions_id_seq;
DROP TABLE public.group_permissions;
DROP SEQUENCE public.friendly_id_slugs_id_seq;
DROP TABLE public.friendly_id_slugs;
DROP SEQUENCE public.file_uploads_id_seq;
DROP TABLE public.file_uploads;
DROP SEQUENCE public.event_lists_id_seq;
DROP TABLE public.event_lists;
DROP SEQUENCE public.event_details_id_seq;
DROP TABLE public.event_details;
DROP SEQUENCE public.error_reports_id_seq;
DROP TABLE public.error_reports;
DROP SEQUENCE public.documents_id_seq;
DROP TABLE public.documents;
DROP SEQUENCE public.delayed_jobs_id_seq;
DROP TABLE public.delayed_jobs;
DROP SEQUENCE public.delayed_allocations_id_seq;
DROP TABLE public.delayed_allocations;
DROP SEQUENCE public.dangerous_classes_id_seq;
DROP TABLE public.dangerous_classes;
DROP SEQUENCE public.daily_assignments_id_seq;
DROP TABLE public.daily_assignments;
DROP SEQUENCE public.currencies_id_seq;
DROP TABLE public.currencies;
DROP SEQUENCE public.containers_id_seq;
DROP TABLE public.containers;
DROP SEQUENCE public.container_types_id_seq;
DROP TABLE public.container_types;
DROP SEQUENCE public.container_psas_id_seq;
DROP TABLE public.container_psas;
DROP SEQUENCE public.container_groups_id_seq;
DROP TABLE public.container_groups;
DROP SEQUENCE public.container_details_id_seq;
DROP TABLE public.container_details;
DROP SEQUENCE public.company_tiers_id_seq;
DROP TABLE public.company_tiers;
DROP SEQUENCE public.companies_id_seq;
DROP TABLE public.companies;
DROP SEQUENCE public.collect_times_id_seq;
DROP TABLE public.collect_times;
DROP SEQUENCE public.carrier_quotations_id_seq;
DROP TABLE public.carrier_quotations;
DROP SEQUENCE public.carrier_payments_id_seq;
DROP TABLE public.carrier_payments;
DROP SEQUENCE public.carrier_assignments_id_seq;
DROP TABLE public.carrier_assignments;
DROP SEQUENCE public.booking_orders_id_seq;
DROP TABLE public.booking_orders;
DROP SEQUENCE public.booking_cargos_id_seq;
DROP TABLE public.booking_cargos;
DROP SEQUENCE public.bid_fors_id_seq;
DROP TABLE public.bid_fors;
DROP SEQUENCE public.assignments_id_seq;
DROP TABLE public.assignments;
DROP TABLE public.ar_internal_metadata;
DROP SEQUENCE public.allocation_assignment_groups_id_seq;
DROP TABLE public.allocation_assignment_groups;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: allocation_assignment_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE allocation_assignment_groups (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    assignee_company_ids integer[] DEFAULT '{}'::integer[],
    daily_import_id integer[] DEFAULT '{}'::integer[],
    daily_export_id integer[] DEFAULT '{}'::integer[]
);


--
-- Name: allocation_assignment_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE allocation_assignment_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: allocation_assignment_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE allocation_assignment_groups_id_seq OWNED BY allocation_assignment_groups.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE assignments (
    id integer NOT NULL,
    user_id integer,
    work_order_id integer,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    price double precision,
    container_id integer,
    unit integer,
    driver boolean DEFAULT false,
    confirmed boolean DEFAULT false
);


--
-- Name: assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE assignments_id_seq OWNED BY assignments.id;


--
-- Name: bid_fors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE bid_fors (
    id integer NOT NULL,
    work_order_id integer,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: bid_fors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE bid_fors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bid_fors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE bid_fors_id_seq OWNED BY bid_fors.id;


--
-- Name: booking_cargos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE booking_cargos (
    id integer NOT NULL,
    bkg_number character varying,
    bl_number character varying,
    dg_cargo_flag character varying,
    dg_booking_approval_status boolean,
    bkg_cargo_type_code character varying,
    container_number character varying,
    container_type_size_code character varying,
    container_quantity character varying,
    first_swd character varying,
    last_swd character varying,
    first_wd_code character varying,
    first_wd_vessel_name character varying,
    first_wd_voyage_number character varying,
    first_wd_direction_code character varying,
    last_wd_code character varying,
    last_wd_vessel_code character varying,
    last_wd_vessel_name character varying,
    last_wd_voyage_number character varying,
    last_wd_direction_code character varying,
    first_pol_location_code character varying,
    last_pod_location_code character varying,
    first_pol_eta_date character varying,
    first_pol_etd_date character varying,
    last_pod_eta_date character varying,
    por_location_code character varying,
    empty_pick_up_date character varying,
    del_location_code character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    first_wd_vessel_code character varying,
    user_id integer,
    status integer,
    line character varying,
    terminal character varying,
    start_date character varying,
    start_time character varying
);


--
-- Name: booking_cargos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE booking_cargos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: booking_cargos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE booking_cargos_id_seq OWNED BY booking_cargos.id;


--
-- Name: booking_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE booking_orders (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    header json,
    details json,
    company_id integer,
    issued_date date
);


--
-- Name: booking_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE booking_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: booking_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE booking_orders_id_seq OWNED BY booking_orders.id;


--
-- Name: carrier_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE carrier_assignments (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    driver_id integer,
    containers json DEFAULT '{}'::json,
    journeys character varying[] DEFAULT '{}'::character varying[]
);


--
-- Name: carrier_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE carrier_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carrier_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE carrier_assignments_id_seq OWNED BY carrier_assignments.id;


--
-- Name: carrier_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE carrier_payments (
    id integer NOT NULL,
    transportation_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: carrier_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE carrier_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carrier_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE carrier_payments_id_seq OWNED BY carrier_payments.id;


--
-- Name: carrier_quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE carrier_quotations (
    id integer NOT NULL,
    price double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_id integer,
    work_order_id integer,
    rejected boolean DEFAULT false,
    container_id integer,
    unit integer
);


--
-- Name: carrier_quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE carrier_quotations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carrier_quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE carrier_quotations_id_seq OWNED BY carrier_quotations.id;


--
-- Name: collect_times; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE collect_times (
    id integer NOT NULL,
    container_id integer,
    pickup_time character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    container_number character varying
);


--
-- Name: collect_times_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE collect_times_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collect_times_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE collect_times_id_seq OWNED BY collect_times.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE companies (
    id integer NOT NULL,
    name character varying,
    caption character varying,
    email character varying,
    carrier boolean DEFAULT false,
    slug character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    receive_email boolean DEFAULT false,
    currency_id integer,
    active boolean
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE companies_id_seq OWNED BY companies.id;


--
-- Name: company_tiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE company_tiers (
    id integer NOT NULL,
    company_id integer,
    tier_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: company_tiers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE company_tiers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_tiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE company_tiers_id_seq OWNED BY company_tiers.id;


--
-- Name: container_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE container_details (
    id integer NOT NULL,
    serial_no character varying,
    seal_no character varying,
    vgm character varying,
    container_id integer,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_id integer,
    last_update json
);


--
-- Name: container_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE container_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: container_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE container_details_id_seq OWNED BY container_details.id;


--
-- Name: container_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE container_groups (
    id integer NOT NULL,
    carrier_quotation_id integer,
    work_order_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: container_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE container_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: container_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE container_groups_id_seq OWNED BY container_groups.id;


--
-- Name: container_psas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE container_psas (
    id integer NOT NULL,
    container_id integer,
    psa_group_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: container_psas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE container_psas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: container_psas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE container_psas_id_seq OWNED BY container_psas.id;


--
-- Name: container_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE container_types (
    id integer NOT NULL,
    code character varying,
    description character varying,
    mode character varying,
    fcl_type character varying,
    teu double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: container_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE container_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: container_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE container_types_id_seq OWNED BY container_types.id;


--
-- Name: containers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE containers (
    id integer NOT NULL,
    work_order_id integer,
    net_weight character varying,
    damaged character varying,
    gross_weight character varying,
    volume character varying,
    height character varying,
    goods_marks character varying,
    goods_description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    serial character varying,
    price double precision,
    frost boolean DEFAULT false,
    ca boolean DEFAULT false,
    chiller boolean DEFAULT false,
    dg boolean DEFAULT false,
    unit integer,
    status integer DEFAULT 0,
    mode integer,
    assigned_units integer DEFAULT 0
);


--
-- Name: containers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE containers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: containers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE containers_id_seq OWNED BY containers.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE currencies (
    id integer NOT NULL,
    name character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE currencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE currencies_id_seq OWNED BY currencies.id;


--
-- Name: daily_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE daily_assignments (
    id integer NOT NULL,
    company_id integer,
    mode integer,
    plan_volume integer,
    volume json,
    rails_allocation_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status integer,
    confirm_token character varying,
    trucker_confirmed boolean DEFAULT false,
    vessels json,
    user_id integer
);


--
-- Name: daily_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE daily_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE daily_assignments_id_seq OWNED BY daily_assignments.id;


--
-- Name: dangerous_classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE dangerous_classes (
    id integer NOT NULL,
    container_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    psa_group_id integer,
    dg_type character varying
);


--
-- Name: dangerous_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE dangerous_classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dangerous_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE dangerous_classes_id_seq OWNED BY dangerous_classes.id;


--
-- Name: delayed_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE delayed_allocations (
    id integer NOT NULL,
    assignment_group_id integer,
    company_ids integer[] DEFAULT '{}'::integer[],
    import_priorities json,
    export_priorities json,
    user_id integer,
    planning_date date,
    vessels json,
    trips json,
    status integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    confirm_token json
);


--
-- Name: delayed_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE delayed_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE delayed_allocations_id_seq OWNED BY delayed_allocations.id;


--
-- Name: delayed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE delayed_jobs (
    id integer NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    handler text NOT NULL,
    last_error text,
    run_at timestamp without time zone,
    locked_at timestamp without time zone,
    failed_at timestamp without time zone,
    locked_by character varying,
    queue character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE delayed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE delayed_jobs_id_seq OWNED BY delayed_jobs.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE documents (
    id integer NOT NULL,
    doc_type integer,
    doc_url character varying,
    work_order_id integer,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    temp_path character varying,
    path character varying,
    status integer DEFAULT 0,
    name character varying,
    open_for_user_id character varying
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE documents_id_seq OWNED BY documents.id;


--
-- Name: error_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE error_reports (
    id integer NOT NULL,
    title character varying,
    error character varying,
    details character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    sequence integer
);


--
-- Name: error_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE error_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: error_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE error_reports_id_seq OWNED BY error_reports.id;


--
-- Name: event_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE event_details (
    id integer NOT NULL,
    event_list_id integer,
    item_group character varying,
    item character varying,
    data character varying
);


--
-- Name: event_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE event_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE event_details_id_seq OWNED BY event_details.id;


--
-- Name: event_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE event_lists (
    id integer NOT NULL,
    work_order_number character varying,
    event_action character varying,
    action_by character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: event_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE event_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE event_lists_id_seq OWNED BY event_lists.id;


--
-- Name: file_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE file_uploads (
    id integer NOT NULL,
    path character varying,
    temp_path character varying,
    status integer DEFAULT 0,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: file_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE file_uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE file_uploads_id_seq OWNED BY file_uploads.id;


--
-- Name: friendly_id_slugs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE friendly_id_slugs (
    id integer NOT NULL,
    slug character varying NOT NULL,
    sluggable_id integer NOT NULL,
    sluggable_type character varying(50),
    scope character varying,
    created_at timestamp without time zone
);


--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE friendly_id_slugs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE friendly_id_slugs_id_seq OWNED BY friendly_id_slugs.id;


--
-- Name: group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE group_permissions (
    id integer NOT NULL,
    name character varying,
    restriction_ids character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE group_permissions_id_seq OWNED BY group_permissions.id;


--
-- Name: import_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE import_files (
    id integer NOT NULL,
    name character varying,
    kind integer,
    user_id integer,
    temp_path character varying,
    path character varying,
    status character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: import_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE import_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: import_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE import_files_id_seq OWNED BY import_files.id;


--
-- Name: indischarges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE indischarges (
    id integer NOT NULL,
    booking_no character varying,
    header json,
    details json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_id integer,
    "from" date,
    "to" date
);


--
-- Name: indischarges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE indischarges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indischarges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE indischarges_id_seq OWNED BY indischarges.id;


--
-- Name: journeys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE journeys (
    id integer NOT NULL,
    from_location character varying,
    from_address character varying,
    from_date character varying,
    from_contact character varying,
    to_location character varying,
    to_address character varying,
    to_date character varying,
    to_contact character varying,
    work_order_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    mode boolean,
    pick_from_time time without time zone,
    pick_to_time time without time zone,
    delivery_from_time time without time zone,
    delivery_to_time time without time zone,
    ready boolean DEFAULT false
);


--
-- Name: journeys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE journeys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journeys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE journeys_id_seq OWNED BY journeys.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE locations (
    id integer NOT NULL,
    name character varying,
    address character varying,
    date date,
    contact character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE locations_id_seq OWNED BY locations.id;


--
-- Name: master_exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE master_exports (
    id integer NOT NULL,
    file_export_name character varying,
    created_by_id integer,
    table_name character varying,
    status boolean,
    errors_message character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    file_upload_id integer
);


--
-- Name: master_exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE master_exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: master_exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE master_exports_id_seq OWNED BY master_exports.id;


--
-- Name: movement_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE movement_events (
    id integer NOT NULL,
    cnt_number character varying,
    cnt_type_size_code character varying,
    cnt_movement_year character varying,
    cnt_movement_cycle_number character varying,
    cnt_movement_status_code character varying,
    cnt_movement_date character varying,
    doc_type_code character varying,
    bkg_number character varying,
    bl_number character varying,
    eqr_ref_no character varying,
    origin_continent_name character varying,
    origin_sub_continent_name character varying,
    origin_country_code character varying,
    origin_ecc_code character varying,
    origin_loc_code character varying,
    origin_yard_code character varying,
    origin_yard_name character varying,
    event_svvd character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer,
    cnt_movement_sequence integer
);


--
-- Name: movement_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE movement_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: movement_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE movement_events_id_seq OWNED BY movement_events.id;


--
-- Name: noti_truckers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE noti_truckers (
    id integer NOT NULL,
    notification_id integer,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    read boolean DEFAULT false
);


--
-- Name: noti_truckers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE noti_truckers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: noti_truckers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE noti_truckers_id_seq OWNED BY noti_truckers.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE notifications (
    id integer NOT NULL,
    message character varying,
    noti_info character varying,
    noti_type integer,
    target integer,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    read boolean DEFAULT false,
    work_order_id integer,
    subject character varying DEFAULT 't'::character varying
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE notifications_id_seq OWNED BY notifications.id;


--
-- Name: outloads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE outloads (
    id integer NOT NULL,
    booking_no character varying,
    header json,
    details json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_id integer,
    "from" date,
    "to" date
);


--
-- Name: outloads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE outloads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outloads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE outloads_id_seq OWNED BY outloads.id;


--
-- Name: performance_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE performance_reports (
    id integer NOT NULL,
    month character varying,
    _date character varying,
    truck character varying,
    export character varying,
    import character varying,
    actual_trip character varying,
    performance character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: performance_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE performance_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: performance_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE performance_reports_id_seq OWNED BY performance_reports.id;


--
-- Name: permits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE permits (
    id integer NOT NULL,
    number character varying,
    temp_path character varying,
    path character varying,
    user_id integer,
    work_order_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status integer
);


--
-- Name: permits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE permits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE permits_id_seq OWNED BY permits.id;


--
-- Name: portnets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE portnets (
    id integer NOT NULL,
    user_id integer,
    company_id integer,
    work_order_id integer,
    portnet boolean DEFAULT false,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    updated boolean DEFAULT false
);


--
-- Name: portnets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE portnets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: portnets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE portnets_id_seq OWNED BY portnets.id;


--
-- Name: priorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE priorities (
    id integer NOT NULL,
    user_id integer,
    percentage json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_id integer
);


--
-- Name: priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE priorities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE priorities_id_seq OWNED BY priorities.id;


--
-- Name: psa_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE psa_groups (
    id integer NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    container_id integer
);


--
-- Name: psa_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE psa_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: psa_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE psa_groups_id_seq OWNED BY psa_groups.id;


--
-- Name: rails_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE rails_allocations (
    id integer NOT NULL,
    planning_date date,
    eta_from date,
    eta_to date,
    volume json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: rails_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE rails_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rails_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE rails_allocations_id_seq OWNED BY rails_allocations.id;


--
-- Name: remarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE remarks (
    id integer NOT NULL,
    remark character varying,
    company_id integer,
    work_order_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


--
-- Name: remarks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE remarks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: remarks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE remarks_id_seq OWNED BY remarks.id;


--
-- Name: restrictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE restrictions (
    id integer NOT NULL,
    _controller character varying,
    _action character varying,
    title character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: restrictions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE restrictions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restrictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE restrictions_id_seq OWNED BY restrictions.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- Name: shipper_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE shipper_payments (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: shipper_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE shipper_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shipper_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE shipper_payments_id_seq OWNED BY shipper_payments.id;


--
-- Name: supports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE supports (
    id integer NOT NULL,
    name character varying,
    email character varying,
    message character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: supports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE supports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE supports_id_seq OWNED BY supports.id;


--
-- Name: temporaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE temporaries (
    id integer NOT NULL,
    item character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    value json,
    error boolean DEFAULT false,
    err_mes character varying
);


--
-- Name: temporaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE temporaries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: temporaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE temporaries_id_seq OWNED BY temporaries.id;


--
-- Name: terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE terms (
    id integer NOT NULL,
    content character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: terms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE terms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE terms_id_seq OWNED BY terms.id;


--
-- Name: tiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE tiers (
    id integer NOT NULL,
    name character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: tiers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tiers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tiers_id_seq OWNED BY tiers.id;


--
-- Name: tracking_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE tracking_imports (
    id integer NOT NULL,
    title character varying,
    seq integer,
    error_ids character varying,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: tracking_imports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tracking_imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tracking_imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tracking_imports_id_seq OWNED BY tracking_imports.id;


--
-- Name: trailers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE trailers (
    id integer NOT NULL,
    number character varying,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    insurance_number character varying,
    insurance_file character varying
);


--
-- Name: trailers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE trailers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trailers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE trailers_id_seq OWNED BY trailers.id;


--
-- Name: transportation_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE transportation_assignments (
    id integer NOT NULL,
    transportation_id integer,
    user_id integer,
    truck_head_id integer,
    trailer_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    company_id integer
);


--
-- Name: transportation_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE transportation_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transportation_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE transportation_assignments_id_seq OWNED BY transportation_assignments.id;


--
-- Name: transportations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE transportations (
    id integer NOT NULL,
    name character varying,
    company_id integer,
    work_order_id integer,
    journey_id integer,
    container_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status integer
);


--
-- Name: transportations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE transportations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transportations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE transportations_id_seq OWNED BY transportations.id;


--
-- Name: truck_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE truck_heads (
    id integer NOT NULL,
    number character varying,
    company_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    insurance_number character varying,
    insurance_file character varying
);


--
-- Name: truck_heads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE truck_heads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: truck_heads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE truck_heads_id_seq OWNED BY truck_heads.id;


--
-- Name: user_restrictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_restrictions (
    id integer NOT NULL,
    user_id integer,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    group_permission_ids character varying
);


--
-- Name: user_restrictions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_restrictions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_restrictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_restrictions_id_seq OWNED BY user_restrictions.id;


--
-- Name: user_trackings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_trackings (
    id integer NOT NULL,
    activity character varying,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: user_trackings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_trackings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_trackings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_trackings_id_seq OWNED BY user_trackings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users (
    id integer NOT NULL,
    name character varying,
    email character varying,
    password_digest character varying,
    company_id integer,
    auth_token character varying,
    admin boolean DEFAULT false,
    manager boolean DEFAULT false,
    email_confirmed boolean DEFAULT false,
    slug character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    role integer,
    image character varying,
    phone_number character varying,
    license_number character varying,
    license_file character varying,
    truck_code character varying,
    active boolean DEFAULT true,
    import boolean DEFAULT false,
    priority boolean DEFAULT true
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: view_last_movements; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW view_last_movements AS
 SELECT booking_cargos.id AS cnt_id,
    c.cnt_number,
    booking_cargos.dg_cargo_flag AS cnt_dg_flag,
    booking_cargos.container_type_size_code AS cnt_type_size_code,
    c.cnt_status,
    c.cnt_sequence
   FROM (booking_cargos
     JOIN ( SELECT a.cnt_number,
            movement_events.cnt_movement_status_code AS cnt_status,
            a.sequence AS cnt_sequence
           FROM (( SELECT movement_events_1.cnt_number,
                    max(movement_events_1.cnt_movement_sequence) AS sequence
                   FROM movement_events movement_events_1
                  GROUP BY movement_events_1.cnt_number) a
             JOIN movement_events ON ((((movement_events.cnt_number)::text = (a.cnt_number)::text) AND (movement_events.cnt_movement_sequence = a.sequence))))) c ON (((booking_cargos.container_number)::text = (c.cnt_number)::text)));


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE work_orders (
    id integer NOT NULL,
    request_no character varying,
    request_rate double precision,
    open_time integer,
    remark character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    shipper character varying,
    consignee character varying,
    vessel character varying,
    carrier character varying,
    etd character varying,
    eta character varying,
    user_id integer,
    auto_reject boolean DEFAULT true,
    active boolean DEFAULT true,
    ends_at timestamp without time zone,
    manual boolean DEFAULT false,
    completed boolean DEFAULT false,
    status integer,
    trunk boolean DEFAULT false,
    original_id integer,
    container_id integer,
    generated_transportation boolean DEFAULT false,
    currency_id integer,
    slug character varying,
    ref_no character varying,
    booking_ref character varying,
    pickup_ref character varying,
    storing_order_ref character varying
);


--
-- Name: work_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE work_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE work_orders_id_seq OWNED BY work_orders.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY allocation_assignment_groups ALTER COLUMN id SET DEFAULT nextval('allocation_assignment_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignments ALTER COLUMN id SET DEFAULT nextval('assignments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY bid_fors ALTER COLUMN id SET DEFAULT nextval('bid_fors_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY booking_cargos ALTER COLUMN id SET DEFAULT nextval('booking_cargos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY booking_orders ALTER COLUMN id SET DEFAULT nextval('booking_orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY carrier_assignments ALTER COLUMN id SET DEFAULT nextval('carrier_assignments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY carrier_payments ALTER COLUMN id SET DEFAULT nextval('carrier_payments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY carrier_quotations ALTER COLUMN id SET DEFAULT nextval('carrier_quotations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY collect_times ALTER COLUMN id SET DEFAULT nextval('collect_times_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY companies ALTER COLUMN id SET DEFAULT nextval('companies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_tiers ALTER COLUMN id SET DEFAULT nextval('company_tiers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_details ALTER COLUMN id SET DEFAULT nextval('container_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_groups ALTER COLUMN id SET DEFAULT nextval('container_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_psas ALTER COLUMN id SET DEFAULT nextval('container_psas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_types ALTER COLUMN id SET DEFAULT nextval('container_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY containers ALTER COLUMN id SET DEFAULT nextval('containers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY currencies ALTER COLUMN id SET DEFAULT nextval('currencies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY daily_assignments ALTER COLUMN id SET DEFAULT nextval('daily_assignments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY dangerous_classes ALTER COLUMN id SET DEFAULT nextval('dangerous_classes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY delayed_allocations ALTER COLUMN id SET DEFAULT nextval('delayed_allocations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY delayed_jobs ALTER COLUMN id SET DEFAULT nextval('delayed_jobs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY documents ALTER COLUMN id SET DEFAULT nextval('documents_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY error_reports ALTER COLUMN id SET DEFAULT nextval('error_reports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY event_details ALTER COLUMN id SET DEFAULT nextval('event_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY event_lists ALTER COLUMN id SET DEFAULT nextval('event_lists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_uploads ALTER COLUMN id SET DEFAULT nextval('file_uploads_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY friendly_id_slugs ALTER COLUMN id SET DEFAULT nextval('friendly_id_slugs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY group_permissions ALTER COLUMN id SET DEFAULT nextval('group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_files ALTER COLUMN id SET DEFAULT nextval('import_files_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY indischarges ALTER COLUMN id SET DEFAULT nextval('indischarges_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY journeys ALTER COLUMN id SET DEFAULT nextval('journeys_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY locations ALTER COLUMN id SET DEFAULT nextval('locations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY master_exports ALTER COLUMN id SET DEFAULT nextval('master_exports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY movement_events ALTER COLUMN id SET DEFAULT nextval('movement_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY noti_truckers ALTER COLUMN id SET DEFAULT nextval('noti_truckers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY notifications ALTER COLUMN id SET DEFAULT nextval('notifications_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY outloads ALTER COLUMN id SET DEFAULT nextval('outloads_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY performance_reports ALTER COLUMN id SET DEFAULT nextval('performance_reports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY permits ALTER COLUMN id SET DEFAULT nextval('permits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY portnets ALTER COLUMN id SET DEFAULT nextval('portnets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY priorities ALTER COLUMN id SET DEFAULT nextval('priorities_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY psa_groups ALTER COLUMN id SET DEFAULT nextval('psa_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY rails_allocations ALTER COLUMN id SET DEFAULT nextval('rails_allocations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY remarks ALTER COLUMN id SET DEFAULT nextval('remarks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY restrictions ALTER COLUMN id SET DEFAULT nextval('restrictions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY shipper_payments ALTER COLUMN id SET DEFAULT nextval('shipper_payments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY supports ALTER COLUMN id SET DEFAULT nextval('supports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY temporaries ALTER COLUMN id SET DEFAULT nextval('temporaries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY terms ALTER COLUMN id SET DEFAULT nextval('terms_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tiers ALTER COLUMN id SET DEFAULT nextval('tiers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY tracking_imports ALTER COLUMN id SET DEFAULT nextval('tracking_imports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY trailers ALTER COLUMN id SET DEFAULT nextval('trailers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportation_assignments ALTER COLUMN id SET DEFAULT nextval('transportation_assignments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportations ALTER COLUMN id SET DEFAULT nextval('transportations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY truck_heads ALTER COLUMN id SET DEFAULT nextval('truck_heads_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_restrictions ALTER COLUMN id SET DEFAULT nextval('user_restrictions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_trackings ALTER COLUMN id SET DEFAULT nextval('user_trackings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY work_orders ALTER COLUMN id SET DEFAULT nextval('work_orders_id_seq'::regclass);


--
-- Data for Name: allocation_assignment_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY allocation_assignment_groups (id, created_at, updated_at, assignee_company_ids, daily_import_id, daily_export_id) FROM stdin;
\.
COPY allocation_assignment_groups (id, created_at, updated_at, assignee_company_ids, daily_import_id, daily_export_id) FROM '$$PATH$$/3835.dat';

--
-- Name: allocation_assignment_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('allocation_assignment_groups_id_seq', 1, false);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3731.dat';

--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY assignments (id, user_id, work_order_id, company_id, created_at, updated_at, price, container_id, unit, driver, confirmed) FROM stdin;
\.
COPY assignments (id, user_id, work_order_id, company_id, created_at, updated_at, price, container_id, unit, driver, confirmed) FROM '$$PATH$$/3751.dat';

--
-- Name: assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('assignments_id_seq', 113, true);


--
-- Data for Name: bid_fors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY bid_fors (id, work_order_id, company_id, created_at, updated_at) FROM stdin;
\.
COPY bid_fors (id, work_order_id, company_id, created_at, updated_at) FROM '$$PATH$$/3753.dat';

--
-- Name: bid_fors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('bid_fors_id_seq', 1164, true);


--
-- Data for Name: booking_cargos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY booking_cargos (id, bkg_number, bl_number, dg_cargo_flag, dg_booking_approval_status, bkg_cargo_type_code, container_number, container_type_size_code, container_quantity, first_swd, last_swd, first_wd_code, first_wd_vessel_name, first_wd_voyage_number, first_wd_direction_code, last_wd_code, last_wd_vessel_code, last_wd_vessel_name, last_wd_voyage_number, last_wd_direction_code, first_pol_location_code, last_pod_location_code, first_pol_eta_date, first_pol_etd_date, last_pod_eta_date, por_location_code, empty_pick_up_date, del_location_code, created_at, updated_at, first_wd_vessel_code, user_id, status, line, terminal, start_date, start_time) FROM stdin;
\.
COPY booking_cargos (id, bkg_number, bl_number, dg_cargo_flag, dg_booking_approval_status, bkg_cargo_type_code, container_number, container_type_size_code, container_quantity, first_swd, last_swd, first_wd_code, first_wd_vessel_name, first_wd_voyage_number, first_wd_direction_code, last_wd_code, last_wd_vessel_code, last_wd_vessel_name, last_wd_voyage_number, last_wd_direction_code, first_pol_location_code, last_pod_location_code, first_pol_eta_date, first_pol_etd_date, last_pod_eta_date, por_location_code, empty_pick_up_date, del_location_code, created_at, updated_at, first_wd_vessel_code, user_id, status, line, terminal, start_date, start_time) FROM '$$PATH$$/3809.dat';

--
-- Name: booking_cargos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('booking_cargos_id_seq', 4472, true);


--
-- Data for Name: booking_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY booking_orders (id, created_at, updated_at, header, details, company_id, issued_date) FROM stdin;
\.
COPY booking_orders (id, created_at, updated_at, header, details, company_id, issued_date) FROM '$$PATH$$/3793.dat';

--
-- Name: booking_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('booking_orders_id_seq', 1, false);


--
-- Data for Name: carrier_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY carrier_assignments (id, created_at, updated_at, driver_id, containers, journeys) FROM stdin;
\.
COPY carrier_assignments (id, created_at, updated_at, driver_id, containers, journeys) FROM '$$PATH$$/3771.dat';

--
-- Name: carrier_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('carrier_assignments_id_seq', 1, false);


--
-- Data for Name: carrier_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY carrier_payments (id, transportation_id, created_at, updated_at) FROM stdin;
\.
COPY carrier_payments (id, transportation_id, created_at, updated_at) FROM '$$PATH$$/3781.dat';

--
-- Name: carrier_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('carrier_payments_id_seq', 1, false);


--
-- Data for Name: carrier_quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY carrier_quotations (id, price, created_at, updated_at, company_id, work_order_id, rejected, container_id, unit) FROM stdin;
\.
COPY carrier_quotations (id, price, created_at, updated_at, company_id, work_order_id, rejected, container_id, unit) FROM '$$PATH$$/3743.dat';

--
-- Name: carrier_quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('carrier_quotations_id_seq', 134, true);


--
-- Data for Name: collect_times; Type: TABLE DATA; Schema: public; Owner: -
--

COPY collect_times (id, container_id, pickup_time, created_at, updated_at, container_number) FROM stdin;
\.
COPY collect_times (id, container_id, pickup_time, created_at, updated_at, container_number) FROM '$$PATH$$/3833.dat';

--
-- Name: collect_times_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('collect_times_id_seq', 24, true);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY companies (id, name, caption, email, carrier, slug, created_at, updated_at, receive_email, currency_id, active) FROM stdin;
\.
COPY companies (id, name, caption, email, carrier, slug, created_at, updated_at, receive_email, currency_id, active) FROM '$$PATH$$/3735.dat';

--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('companies_id_seq', 23, true);


--
-- Data for Name: company_tiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY company_tiers (id, company_id, tier_id, created_at, updated_at) FROM stdin;
\.
COPY company_tiers (id, company_id, tier_id, created_at, updated_at) FROM '$$PATH$$/3769.dat';

--
-- Name: company_tiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('company_tiers_id_seq', 1, false);


--
-- Data for Name: container_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY container_details (id, serial_no, seal_no, vgm, container_id, user_id, created_at, updated_at, company_id, last_update) FROM stdin;
\.
COPY container_details (id, serial_no, seal_no, vgm, container_id, user_id, created_at, updated_at, company_id, last_update) FROM '$$PATH$$/3819.dat';

--
-- Name: container_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('container_details_id_seq', 267, true);


--
-- Data for Name: container_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY container_groups (id, carrier_quotation_id, work_order_id, created_at, updated_at) FROM stdin;
\.
COPY container_groups (id, carrier_quotation_id, work_order_id, created_at, updated_at) FROM '$$PATH$$/3759.dat';

--
-- Name: container_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('container_groups_id_seq', 1, false);


--
-- Data for Name: container_psas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY container_psas (id, container_id, psa_group_id, created_at, updated_at) FROM stdin;
\.
COPY container_psas (id, container_id, psa_group_id, created_at, updated_at) FROM '$$PATH$$/3847.dat';

--
-- Name: container_psas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('container_psas_id_seq', 19, true);


--
-- Data for Name: container_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY container_types (id, code, description, mode, fcl_type, teu, created_at, updated_at) FROM stdin;
\.
COPY container_types (id, code, description, mode, fcl_type, teu, created_at, updated_at) FROM '$$PATH$$/3765.dat';

--
-- Name: container_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('container_types_id_seq', 8, true);


--
-- Data for Name: containers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY containers (id, work_order_id, net_weight, damaged, gross_weight, volume, height, goods_marks, goods_description, created_at, updated_at, serial, price, frost, ca, chiller, dg, unit, status, mode, assigned_units) FROM stdin;
\.
COPY containers (id, work_order_id, net_weight, damaged, gross_weight, volume, height, goods_marks, goods_description, created_at, updated_at, serial, price, frost, ca, chiller, dg, unit, status, mode, assigned_units) FROM '$$PATH$$/3745.dat';

--
-- Name: containers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('containers_id_seq', 136, true);


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY currencies (id, name, description, created_at, updated_at) FROM stdin;
\.
COPY currencies (id, name, description, created_at, updated_at) FROM '$$PATH$$/3787.dat';

--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('currencies_id_seq', 2, true);


--
-- Data for Name: daily_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY daily_assignments (id, company_id, mode, plan_volume, volume, rails_allocation_id, created_at, updated_at, status, confirm_token, trucker_confirmed, vessels, user_id) FROM stdin;
\.
COPY daily_assignments (id, company_id, mode, plan_volume, volume, rails_allocation_id, created_at, updated_at, status, confirm_token, trucker_confirmed, vessels, user_id) FROM '$$PATH$$/3823.dat';

--
-- Name: daily_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('daily_assignments_id_seq', 1, false);


--
-- Data for Name: dangerous_classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY dangerous_classes (id, container_id, created_at, updated_at, psa_group_id, dg_type) FROM stdin;
\.
COPY dangerous_classes (id, container_id, created_at, updated_at, psa_group_id, dg_type) FROM '$$PATH$$/3837.dat';

--
-- Name: dangerous_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('dangerous_classes_id_seq', 19, true);


--
-- Data for Name: delayed_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY delayed_allocations (id, assignment_group_id, company_ids, import_priorities, export_priorities, user_id, planning_date, vessels, trips, status, created_at, updated_at, confirm_token) FROM stdin;
\.
COPY delayed_allocations (id, assignment_group_id, company_ids, import_priorities, export_priorities, user_id, planning_date, vessels, trips, status, created_at, updated_at, confirm_token) FROM '$$PATH$$/3839.dat';

--
-- Name: delayed_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('delayed_allocations_id_seq', 1, false);


--
-- Data for Name: delayed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY delayed_jobs (id, priority, attempts, handler, last_error, run_at, locked_at, failed_at, locked_by, queue, created_at, updated_at) FROM stdin;
\.
COPY delayed_jobs (id, priority, attempts, handler, last_error, run_at, locked_at, failed_at, locked_by, queue, created_at, updated_at) FROM '$$PATH$$/3737.dat';

--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('delayed_jobs_id_seq', 1636, true);


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY documents (id, doc_type, doc_url, work_order_id, user_id, created_at, updated_at, temp_path, path, status, name, open_for_user_id) FROM stdin;
\.
COPY documents (id, doc_type, doc_url, work_order_id, user_id, created_at, updated_at, temp_path, path, status, name, open_for_user_id) FROM '$$PATH$$/3761.dat';

--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('documents_id_seq', 88, true);


--
-- Data for Name: error_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY error_reports (id, title, error, details, created_at, updated_at, sequence) FROM stdin;
\.
COPY error_reports (id, title, error, details, created_at, updated_at, sequence) FROM '$$PATH$$/3825.dat';

--
-- Name: error_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('error_reports_id_seq', 3, true);


--
-- Data for Name: event_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY event_details (id, event_list_id, item_group, item, data) FROM stdin;
\.
COPY event_details (id, event_list_id, item_group, item, data) FROM '$$PATH$$/3791.dat';

--
-- Name: event_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('event_details_id_seq', 6337, true);


--
-- Data for Name: event_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY event_lists (id, work_order_number, event_action, action_by, created_at, updated_at) FROM stdin;
\.
COPY event_lists (id, work_order_number, event_action, action_by, created_at, updated_at) FROM '$$PATH$$/3789.dat';

--
-- Name: event_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('event_lists_id_seq', 504, true);


--
-- Data for Name: file_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY file_uploads (id, path, temp_path, status, created_at, updated_at) FROM stdin;
\.
COPY file_uploads (id, path, temp_path, status, created_at, updated_at) FROM '$$PATH$$/3849.dat';

--
-- Name: file_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('file_uploads_id_seq', 9, true);


--
-- Data for Name: friendly_id_slugs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY friendly_id_slugs (id, slug, sluggable_id, sluggable_type, scope, created_at) FROM stdin;
\.
COPY friendly_id_slugs (id, slug, sluggable_id, sluggable_type, scope, created_at) FROM '$$PATH$$/3733.dat';

--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('friendly_id_slugs_id_seq', 23, true);


--
-- Data for Name: group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY group_permissions (id, name, restriction_ids, description, created_at, updated_at) FROM stdin;
\.
COPY group_permissions (id, name, restriction_ids, description, created_at, updated_at) FROM '$$PATH$$/3815.dat';

--
-- Name: group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('group_permissions_id_seq', 3, true);


--
-- Data for Name: import_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY import_files (id, name, kind, user_id, temp_path, path, status, created_at, updated_at) FROM stdin;
\.
COPY import_files (id, name, kind, user_id, temp_path, path, status, created_at, updated_at) FROM '$$PATH$$/3803.dat';

--
-- Name: import_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('import_files_id_seq', 40, true);


--
-- Data for Name: indischarges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY indischarges (id, booking_no, header, details, created_at, updated_at, company_id, "from", "to") FROM stdin;
\.
COPY indischarges (id, booking_no, header, details, created_at, updated_at, company_id, "from", "to") FROM '$$PATH$$/3799.dat';

--
-- Name: indischarges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('indischarges_id_seq', 1, false);


--
-- Data for Name: journeys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY journeys (id, from_location, from_address, from_date, from_contact, to_location, to_address, to_date, to_contact, work_order_id, created_at, updated_at, mode, pick_from_time, pick_to_time, delivery_from_time, delivery_to_time, ready) FROM stdin;
\.
COPY journeys (id, from_location, from_address, from_date, from_contact, to_location, to_address, to_date, to_contact, work_order_id, created_at, updated_at, mode, pick_from_time, pick_to_time, delivery_from_time, delivery_to_time, ready) FROM '$$PATH$$/3749.dat';

--
-- Name: journeys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('journeys_id_seq', 205, true);


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY locations (id, name, address, date, contact, created_at, updated_at) FROM stdin;
\.
COPY locations (id, name, address, date, contact, created_at, updated_at) FROM '$$PATH$$/3747.dat';

--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('locations_id_seq', 1, false);


--
-- Data for Name: master_exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY master_exports (id, file_export_name, created_by_id, table_name, status, errors_message, created_at, updated_at, file_upload_id) FROM stdin;
\.
COPY master_exports (id, file_export_name, created_by_id, table_name, status, errors_message, created_at, updated_at, file_upload_id) FROM '$$PATH$$/3843.dat';

--
-- Name: master_exports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('master_exports_id_seq', 10, true);


--
-- Data for Name: movement_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY movement_events (id, cnt_number, cnt_type_size_code, cnt_movement_year, cnt_movement_cycle_number, cnt_movement_status_code, cnt_movement_date, doc_type_code, bkg_number, bl_number, eqr_ref_no, origin_continent_name, origin_sub_continent_name, origin_country_code, origin_ecc_code, origin_loc_code, origin_yard_code, origin_yard_name, event_svvd, created_at, updated_at, user_id, cnt_movement_sequence) FROM stdin;
\.
COPY movement_events (id, cnt_number, cnt_type_size_code, cnt_movement_year, cnt_movement_cycle_number, cnt_movement_status_code, cnt_movement_date, doc_type_code, bkg_number, bl_number, eqr_ref_no, origin_continent_name, origin_sub_continent_name, origin_country_code, origin_ecc_code, origin_loc_code, origin_yard_code, origin_yard_name, event_svvd, created_at, updated_at, user_id, cnt_movement_sequence) FROM '$$PATH$$/3817.dat';

--
-- Name: movement_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('movement_events_id_seq', 343366, true);


--
-- Data for Name: noti_truckers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY noti_truckers (id, notification_id, company_id, created_at, updated_at, read) FROM stdin;
\.
COPY noti_truckers (id, notification_id, company_id, created_at, updated_at, read) FROM '$$PATH$$/3757.dat';

--
-- Name: noti_truckers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('noti_truckers_id_seq', 1450, true);


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY notifications (id, message, noti_info, noti_type, target, user_id, created_at, updated_at, read, work_order_id, subject) FROM stdin;
\.
COPY notifications (id, message, noti_info, noti_type, target, user_id, created_at, updated_at, read, work_order_id, subject) FROM '$$PATH$$/3755.dat';

--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('notifications_id_seq', 1020, true);


--
-- Data for Name: outloads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY outloads (id, booking_no, header, details, created_at, updated_at, company_id, "from", "to") FROM stdin;
\.
COPY outloads (id, booking_no, header, details, created_at, updated_at, company_id, "from", "to") FROM '$$PATH$$/3797.dat';

--
-- Name: outloads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('outloads_id_seq', 1, false);


--
-- Data for Name: performance_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY performance_reports (id, month, _date, truck, export, import, actual_trip, performance, created_at, updated_at) FROM stdin;
\.
COPY performance_reports (id, month, _date, truck, export, import, actual_trip, performance, created_at, updated_at) FROM '$$PATH$$/3801.dat';

--
-- Name: performance_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('performance_reports_id_seq', 1, false);


--
-- Data for Name: permits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY permits (id, number, temp_path, path, user_id, work_order_id, created_at, updated_at, status) FROM stdin;
\.
COPY permits (id, number, temp_path, path, user_id, work_order_id, created_at, updated_at, status) FROM '$$PATH$$/3831.dat';

--
-- Name: permits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('permits_id_seq', 16, true);


--
-- Data for Name: portnets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY portnets (id, user_id, company_id, work_order_id, portnet, created_at, updated_at, updated) FROM stdin;
\.
COPY portnets (id, user_id, company_id, work_order_id, portnet, created_at, updated_at, updated) FROM '$$PATH$$/3841.dat';

--
-- Name: portnets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('portnets_id_seq', 78, true);


--
-- Data for Name: priorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY priorities (id, user_id, percentage, created_at, updated_at, company_id) FROM stdin;
\.
COPY priorities (id, user_id, percentage, created_at, updated_at, company_id) FROM '$$PATH$$/3829.dat';

--
-- Name: priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('priorities_id_seq', 1, false);


--
-- Data for Name: psa_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY psa_groups (id, name, created_at, updated_at, container_id) FROM stdin;
\.
COPY psa_groups (id, name, created_at, updated_at, container_id) FROM '$$PATH$$/3845.dat';

--
-- Name: psa_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('psa_groups_id_seq', 8, true);


--
-- Data for Name: rails_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY rails_allocations (id, planning_date, eta_from, eta_to, volume, created_at, updated_at) FROM stdin;
\.
COPY rails_allocations (id, planning_date, eta_from, eta_to, volume, created_at, updated_at) FROM '$$PATH$$/3821.dat';

--
-- Name: rails_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('rails_allocations_id_seq', 1, false);


--
-- Data for Name: remarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY remarks (id, remark, company_id, work_order_id, created_at, updated_at, user_id) FROM stdin;
\.
COPY remarks (id, remark, company_id, work_order_id, created_at, updated_at, user_id) FROM '$$PATH$$/3763.dat';

--
-- Name: remarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('remarks_id_seq', 101, true);


--
-- Data for Name: restrictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY restrictions (id, _controller, _action, title, description, created_at, updated_at) FROM stdin;
\.
COPY restrictions (id, _controller, _action, title, description, created_at, updated_at) FROM '$$PATH$$/3813.dat';

--
-- Name: restrictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('restrictions_id_seq', 9, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/3730.dat';

--
-- Data for Name: shipper_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY shipper_payments (id, created_at, updated_at) FROM stdin;
\.
COPY shipper_payments (id, created_at, updated_at) FROM '$$PATH$$/3783.dat';

--
-- Name: shipper_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('shipper_payments_id_seq', 1, false);


--
-- Data for Name: supports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY supports (id, name, email, message, created_at, updated_at) FROM stdin;
\.
COPY supports (id, name, email, message, created_at, updated_at) FROM '$$PATH$$/3785.dat';

--
-- Name: supports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('supports_id_seq', 1, false);


--
-- Data for Name: temporaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY temporaries (id, item, created_at, updated_at, value, error, err_mes) FROM stdin;
\.
COPY temporaries (id, item, created_at, updated_at, value, error, err_mes) FROM '$$PATH$$/3795.dat';

--
-- Name: temporaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('temporaries_id_seq', 30, true);


--
-- Data for Name: terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY terms (id, content, created_at, updated_at) FROM stdin;
\.
COPY terms (id, content, created_at, updated_at) FROM '$$PATH$$/3807.dat';

--
-- Name: terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('terms_id_seq', 1, true);


--
-- Data for Name: tiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tiers (id, name, description, created_at, updated_at) FROM stdin;
\.
COPY tiers (id, name, description, created_at, updated_at) FROM '$$PATH$$/3767.dat';

--
-- Name: tiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tiers_id_seq', 1, false);


--
-- Data for Name: tracking_imports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tracking_imports (id, title, seq, error_ids, note, created_at, updated_at) FROM stdin;
\.
COPY tracking_imports (id, title, seq, error_ids, note, created_at, updated_at) FROM '$$PATH$$/3827.dat';

--
-- Name: tracking_imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tracking_imports_id_seq', 4, true);


--
-- Data for Name: trailers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY trailers (id, number, company_id, created_at, updated_at, insurance_number, insurance_file) FROM stdin;
\.
COPY trailers (id, number, company_id, created_at, updated_at, insurance_number, insurance_file) FROM '$$PATH$$/3777.dat';

--
-- Name: trailers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('trailers_id_seq', 1, true);


--
-- Data for Name: transportation_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transportation_assignments (id, transportation_id, user_id, truck_head_id, trailer_id, created_at, updated_at, company_id) FROM stdin;
\.
COPY transportation_assignments (id, transportation_id, user_id, truck_head_id, trailer_id, created_at, updated_at, company_id) FROM '$$PATH$$/3779.dat';

--
-- Name: transportation_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transportation_assignments_id_seq', 3, true);


--
-- Data for Name: transportations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transportations (id, name, company_id, work_order_id, journey_id, container_id, created_at, updated_at, status) FROM stdin;
\.
COPY transportations (id, name, company_id, work_order_id, journey_id, container_id, created_at, updated_at, status) FROM '$$PATH$$/3773.dat';

--
-- Name: transportations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transportations_id_seq', 319, true);


--
-- Data for Name: truck_heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY truck_heads (id, number, company_id, created_at, updated_at, insurance_number, insurance_file) FROM stdin;
\.
COPY truck_heads (id, number, company_id, created_at, updated_at, insurance_number, insurance_file) FROM '$$PATH$$/3775.dat';

--
-- Name: truck_heads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('truck_heads_id_seq', 2, true);


--
-- Data for Name: user_restrictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_restrictions (id, user_id, description, created_at, updated_at, group_permission_ids) FROM stdin;
\.
COPY user_restrictions (id, user_id, description, created_at, updated_at, group_permission_ids) FROM '$$PATH$$/3811.dat';

--
-- Name: user_restrictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_restrictions_id_seq', 7, true);


--
-- Data for Name: user_trackings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_trackings (id, activity, user_id, created_at, updated_at) FROM stdin;
\.
COPY user_trackings (id, activity, user_id, created_at, updated_at) FROM '$$PATH$$/3805.dat';

--
-- Name: user_trackings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_trackings_id_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, name, email, password_digest, company_id, auth_token, admin, manager, email_confirmed, slug, created_at, updated_at, role, image, phone_number, license_number, license_file, truck_code, active, import, priority) FROM stdin;
\.
COPY users (id, name, email, password_digest, company_id, auth_token, admin, manager, email_confirmed, slug, created_at, updated_at, role, image, phone_number, license_number, license_file, truck_code, active, import, priority) FROM '$$PATH$$/3739.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 22, true);


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY work_orders (id, request_no, request_rate, open_time, remark, created_at, updated_at, shipper, consignee, vessel, carrier, etd, eta, user_id, auto_reject, active, ends_at, manual, completed, status, trunk, original_id, container_id, generated_transportation, currency_id, slug, ref_no, booking_ref, pickup_ref, storing_order_ref) FROM stdin;
\.
COPY work_orders (id, request_no, request_rate, open_time, remark, created_at, updated_at, shipper, consignee, vessel, carrier, etd, eta, user_id, auto_reject, active, ends_at, manual, completed, status, trunk, original_id, container_id, generated_transportation, currency_id, slug, ref_no, booking_ref, pickup_ref, storing_order_ref) FROM '$$PATH$$/3741.dat';

--
-- Name: work_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('work_orders_id_seq', 124, true);


--
-- Name: allocation_assignment_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY allocation_assignment_groups
    ADD CONSTRAINT allocation_assignment_groups_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (id);


--
-- Name: bid_fors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bid_fors
    ADD CONSTRAINT bid_fors_pkey PRIMARY KEY (id);


--
-- Name: booking_cargos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY booking_cargos
    ADD CONSTRAINT booking_cargos_pkey PRIMARY KEY (id);


--
-- Name: booking_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY booking_orders
    ADD CONSTRAINT booking_orders_pkey PRIMARY KEY (id);


--
-- Name: carrier_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY carrier_assignments
    ADD CONSTRAINT carrier_assignments_pkey PRIMARY KEY (id);


--
-- Name: carrier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY carrier_payments
    ADD CONSTRAINT carrier_payments_pkey PRIMARY KEY (id);


--
-- Name: carrier_quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY carrier_quotations
    ADD CONSTRAINT carrier_quotations_pkey PRIMARY KEY (id);


--
-- Name: collect_times_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY collect_times
    ADD CONSTRAINT collect_times_pkey PRIMARY KEY (id);


--
-- Name: companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_tiers
    ADD CONSTRAINT company_tiers_pkey PRIMARY KEY (id);


--
-- Name: container_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_details
    ADD CONSTRAINT container_details_pkey PRIMARY KEY (id);


--
-- Name: container_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_groups
    ADD CONSTRAINT container_groups_pkey PRIMARY KEY (id);


--
-- Name: container_psas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_psas
    ADD CONSTRAINT container_psas_pkey PRIMARY KEY (id);


--
-- Name: container_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_types
    ADD CONSTRAINT container_types_pkey PRIMARY KEY (id);


--
-- Name: containers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY containers
    ADD CONSTRAINT containers_pkey PRIMARY KEY (id);


--
-- Name: currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: daily_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY daily_assignments
    ADD CONSTRAINT daily_assignments_pkey PRIMARY KEY (id);


--
-- Name: dangerous_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dangerous_classes
    ADD CONSTRAINT dangerous_classes_pkey PRIMARY KEY (id);


--
-- Name: delayed_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY delayed_allocations
    ADD CONSTRAINT delayed_allocations_pkey PRIMARY KEY (id);


--
-- Name: delayed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY delayed_jobs
    ADD CONSTRAINT delayed_jobs_pkey PRIMARY KEY (id);


--
-- Name: documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: error_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY error_reports
    ADD CONSTRAINT error_reports_pkey PRIMARY KEY (id);


--
-- Name: event_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY event_details
    ADD CONSTRAINT event_details_pkey PRIMARY KEY (id);


--
-- Name: event_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY event_lists
    ADD CONSTRAINT event_lists_pkey PRIMARY KEY (id);


--
-- Name: file_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_uploads
    ADD CONSTRAINT file_uploads_pkey PRIMARY KEY (id);


--
-- Name: friendly_id_slugs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY friendly_id_slugs
    ADD CONSTRAINT friendly_id_slugs_pkey PRIMARY KEY (id);


--
-- Name: group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY group_permissions
    ADD CONSTRAINT group_permissions_pkey PRIMARY KEY (id);


--
-- Name: import_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY import_files
    ADD CONSTRAINT import_files_pkey PRIMARY KEY (id);


--
-- Name: indischarges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY indischarges
    ADD CONSTRAINT indischarges_pkey PRIMARY KEY (id);


--
-- Name: journeys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY journeys
    ADD CONSTRAINT journeys_pkey PRIMARY KEY (id);


--
-- Name: locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: master_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY master_exports
    ADD CONSTRAINT master_exports_pkey PRIMARY KEY (id);


--
-- Name: movement_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY movement_events
    ADD CONSTRAINT movement_events_pkey PRIMARY KEY (id);


--
-- Name: noti_truckers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY noti_truckers
    ADD CONSTRAINT noti_truckers_pkey PRIMARY KEY (id);


--
-- Name: notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outloads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY outloads
    ADD CONSTRAINT outloads_pkey PRIMARY KEY (id);


--
-- Name: performance_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY performance_reports
    ADD CONSTRAINT performance_reports_pkey PRIMARY KEY (id);


--
-- Name: permits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY permits
    ADD CONSTRAINT permits_pkey PRIMARY KEY (id);


--
-- Name: portnets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY portnets
    ADD CONSTRAINT portnets_pkey PRIMARY KEY (id);


--
-- Name: priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (id);


--
-- Name: psa_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY psa_groups
    ADD CONSTRAINT psa_groups_pkey PRIMARY KEY (id);


--
-- Name: rails_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rails_allocations
    ADD CONSTRAINT rails_allocations_pkey PRIMARY KEY (id);


--
-- Name: remarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY remarks
    ADD CONSTRAINT remarks_pkey PRIMARY KEY (id);


--
-- Name: restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY restrictions
    ADD CONSTRAINT restrictions_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: shipper_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY shipper_payments
    ADD CONSTRAINT shipper_payments_pkey PRIMARY KEY (id);


--
-- Name: supports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY supports
    ADD CONSTRAINT supports_pkey PRIMARY KEY (id);


--
-- Name: temporaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY temporaries
    ADD CONSTRAINT temporaries_pkey PRIMARY KEY (id);


--
-- Name: terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (id);


--
-- Name: tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tiers
    ADD CONSTRAINT tiers_pkey PRIMARY KEY (id);


--
-- Name: tracking_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tracking_imports
    ADD CONSTRAINT tracking_imports_pkey PRIMARY KEY (id);


--
-- Name: trailers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY trailers
    ADD CONSTRAINT trailers_pkey PRIMARY KEY (id);


--
-- Name: transportation_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportation_assignments
    ADD CONSTRAINT transportation_assignments_pkey PRIMARY KEY (id);


--
-- Name: transportations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportations
    ADD CONSTRAINT transportations_pkey PRIMARY KEY (id);


--
-- Name: truck_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY truck_heads
    ADD CONSTRAINT truck_heads_pkey PRIMARY KEY (id);


--
-- Name: user_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_restrictions
    ADD CONSTRAINT user_restrictions_pkey PRIMARY KEY (id);


--
-- Name: user_trackings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_trackings
    ADD CONSTRAINT user_trackings_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: delayed_jobs_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delayed_jobs_priority ON delayed_jobs USING btree (priority, run_at);


--
-- Name: index_assignments_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_assignments_on_company_id ON assignments USING btree (company_id);


--
-- Name: index_assignments_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_assignments_on_user_id ON assignments USING btree (user_id);


--
-- Name: index_assignments_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_assignments_on_work_order_id ON assignments USING btree (work_order_id);


--
-- Name: index_bid_fors_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bid_fors_on_company_id ON bid_fors USING btree (company_id);


--
-- Name: index_bid_fors_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bid_fors_on_work_order_id ON bid_fors USING btree (work_order_id);


--
-- Name: index_booking_cargos_on_container_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_booking_cargos_on_container_number ON booking_cargos USING btree (container_number);


--
-- Name: index_companies_on_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_companies_on_slug ON companies USING btree (slug);


--
-- Name: index_company_tiers_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_company_tiers_on_company_id ON company_tiers USING btree (company_id);


--
-- Name: index_company_tiers_on_tier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_company_tiers_on_tier_id ON company_tiers USING btree (tier_id);


--
-- Name: index_container_groups_on_carrier_quotation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_container_groups_on_carrier_quotation_id ON container_groups USING btree (carrier_quotation_id);


--
-- Name: index_container_groups_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_container_groups_on_work_order_id ON container_groups USING btree (work_order_id);


--
-- Name: index_containers_on_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_containers_on_mode ON containers USING btree (mode);


--
-- Name: index_containers_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_containers_on_work_order_id ON containers USING btree (work_order_id);


--
-- Name: index_daily_assignments_on_confirm_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_daily_assignments_on_confirm_token ON daily_assignments USING btree (confirm_token);


--
-- Name: index_dangerous_classes_on_container_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_dangerous_classes_on_container_id ON dangerous_classes USING btree (container_id);


--
-- Name: index_documents_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_user_id ON documents USING btree (user_id);


--
-- Name: index_documents_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_work_order_id ON documents USING btree (work_order_id);


--
-- Name: index_event_details_on_event_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_event_details_on_event_list_id ON event_details USING btree (event_list_id);


--
-- Name: index_event_lists_on_work_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_event_lists_on_work_order_number ON event_lists USING btree (work_order_number);


--
-- Name: index_friendly_id_slugs_on_slug_and_sluggable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_friendly_id_slugs_on_slug_and_sluggable_type ON friendly_id_slugs USING btree (slug, sluggable_type);


--
-- Name: index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope ON friendly_id_slugs USING btree (slug, sluggable_type, scope);


--
-- Name: index_friendly_id_slugs_on_sluggable_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_friendly_id_slugs_on_sluggable_id ON friendly_id_slugs USING btree (sluggable_id);


--
-- Name: index_friendly_id_slugs_on_sluggable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_friendly_id_slugs_on_sluggable_type ON friendly_id_slugs USING btree (sluggable_type);


--
-- Name: index_journeys_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journeys_on_work_order_id ON journeys USING btree (work_order_id);


--
-- Name: index_master_exports_on_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_master_exports_on_created_by_id ON master_exports USING btree (created_by_id);


--
-- Name: index_master_exports_on_file_upload_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_master_exports_on_file_upload_id ON master_exports USING btree (file_upload_id);


--
-- Name: index_movement_events_on_cnt_movement_status_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_movement_events_on_cnt_movement_status_code ON movement_events USING btree (cnt_movement_status_code);


--
-- Name: index_movement_events_on_cnt_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_movement_events_on_cnt_number ON movement_events USING btree (cnt_number);


--
-- Name: index_noti_truckers_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_noti_truckers_on_company_id ON noti_truckers USING btree (company_id);


--
-- Name: index_noti_truckers_on_notification_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_noti_truckers_on_notification_id ON noti_truckers USING btree (notification_id);


--
-- Name: index_notifications_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_user_id ON notifications USING btree (user_id);


--
-- Name: index_remarks_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_remarks_on_company_id ON remarks USING btree (company_id);


--
-- Name: index_remarks_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_remarks_on_user_id ON remarks USING btree (user_id);


--
-- Name: index_remarks_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_remarks_on_work_order_id ON remarks USING btree (work_order_id);


--
-- Name: index_trailers_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_trailers_on_company_id ON trailers USING btree (company_id);


--
-- Name: index_transportation_assignments_on_trailer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportation_assignments_on_trailer_id ON transportation_assignments USING btree (trailer_id);


--
-- Name: index_transportation_assignments_on_transportation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportation_assignments_on_transportation_id ON transportation_assignments USING btree (transportation_id);


--
-- Name: index_transportation_assignments_on_truck_head_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportation_assignments_on_truck_head_id ON transportation_assignments USING btree (truck_head_id);


--
-- Name: index_transportation_assignments_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportation_assignments_on_user_id ON transportation_assignments USING btree (user_id);


--
-- Name: index_transportations_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportations_on_company_id ON transportations USING btree (company_id);


--
-- Name: index_transportations_on_container_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportations_on_container_id ON transportations USING btree (container_id);


--
-- Name: index_transportations_on_journey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportations_on_journey_id ON transportations USING btree (journey_id);


--
-- Name: index_transportations_on_work_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_transportations_on_work_order_id ON transportations USING btree (work_order_id);


--
-- Name: index_truck_heads_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_truck_heads_on_company_id ON truck_heads USING btree (company_id);


--
-- Name: index_user_trackings_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_trackings_on_user_id ON user_trackings USING btree (user_id);


--
-- Name: index_users_on_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_company_id ON users USING btree (company_id);


--
-- Name: index_users_on_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_slug ON users USING btree (slug);


--
-- Name: index_work_orders_on_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_work_orders_on_slug ON work_orders USING btree (slug);


--
-- Name: mov_index1; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mov_index1 ON movement_events USING btree (cnt_number, cnt_movement_status_code, cnt_movement_sequence);


--
-- Name: fk_rails_018e0f79f5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportations
    ADD CONSTRAINT fk_rails_018e0f79f5 FOREIGN KEY (container_id) REFERENCES containers(id);


--
-- Name: fk_rails_0f807e0752; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportations
    ADD CONSTRAINT fk_rails_0f807e0752 FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_20a77c438c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY documents
    ADD CONSTRAINT fk_rails_20a77c438c FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_2492f05953; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportation_assignments
    ADD CONSTRAINT fk_rails_2492f05953 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_rails_2be0318c46; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY documents
    ADD CONSTRAINT fk_rails_2be0318c46 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_rails_34f548048f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY noti_truckers
    ADD CONSTRAINT fk_rails_34f548048f FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_36401535f0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY containers
    ADD CONSTRAINT fk_rails_36401535f0 FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_451c40309f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bid_fors
    ADD CONSTRAINT fk_rails_451c40309f FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_5a1b4dd1a9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignments
    ADD CONSTRAINT fk_rails_5a1b4dd1a9 FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_5f7846a331; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportation_assignments
    ADD CONSTRAINT fk_rails_5f7846a331 FOREIGN KEY (transportation_id) REFERENCES transportations(id);


--
-- Name: fk_rails_607ab95c36; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY journeys
    ADD CONSTRAINT fk_rails_607ab95c36 FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_7682a3bdfe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT fk_rails_7682a3bdfe FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_7a06624a86; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bid_fors
    ADD CONSTRAINT fk_rails_7a06624a86 FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_7fa458e19f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_tiers
    ADD CONSTRAINT fk_rails_7fa458e19f FOREIGN KEY (tier_id) REFERENCES tiers(id);


--
-- Name: fk_rails_863f95b586; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportation_assignments
    ADD CONSTRAINT fk_rails_863f95b586 FOREIGN KEY (truck_head_id) REFERENCES truck_heads(id);


--
-- Name: fk_rails_969bd1d1e2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY trailers
    ADD CONSTRAINT fk_rails_969bd1d1e2 FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_9e2526b1f7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignments
    ADD CONSTRAINT fk_rails_9e2526b1f7 FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_a21139870a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportations
    ADD CONSTRAINT fk_rails_a21139870a FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_aa6b76dac2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignments
    ADD CONSTRAINT fk_rails_aa6b76dac2 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_rails_af04ab7590; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportations
    ADD CONSTRAINT fk_rails_af04ab7590 FOREIGN KEY (journey_id) REFERENCES journeys(id);


--
-- Name: fk_rails_b080fb4855; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT fk_rails_b080fb4855 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_rails_be53cc8828; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY remarks
    ADD CONSTRAINT fk_rails_be53cc8828 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_rails_c6595a9f62; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_groups
    ADD CONSTRAINT fk_rails_c6595a9f62 FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- Name: fk_rails_cb06650eb5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transportation_assignments
    ADD CONSTRAINT fk_rails_cb06650eb5 FOREIGN KEY (trailer_id) REFERENCES trailers(id);


--
-- Name: fk_rails_ce936c5075; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY dangerous_classes
    ADD CONSTRAINT fk_rails_ce936c5075 FOREIGN KEY (container_id) REFERENCES containers(id);


--
-- Name: fk_rails_d07f33023c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY noti_truckers
    ADD CONSTRAINT fk_rails_d07f33023c FOREIGN KEY (notification_id) REFERENCES notifications(id);


--
-- Name: fk_rails_dd1ea8a239; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY remarks
    ADD CONSTRAINT fk_rails_dd1ea8a239 FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_de593c7900; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_tiers
    ADD CONSTRAINT fk_rails_de593c7900 FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_de5a88ae1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY container_groups
    ADD CONSTRAINT fk_rails_de5a88ae1a FOREIGN KEY (carrier_quotation_id) REFERENCES carrier_quotations(id);


--
-- Name: fk_rails_ee027e25bf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY truck_heads
    ADD CONSTRAINT fk_rails_ee027e25bf FOREIGN KEY (company_id) REFERENCES companies(id);


--
-- Name: fk_rails_efe233af29; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_trackings
    ADD CONSTRAINT fk_rails_efe233af29 FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: fk_rails_f50eebf7d7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY master_exports
    ADD CONSTRAINT fk_rails_f50eebf7d7 FOREIGN KEY (file_upload_id) REFERENCES file_uploads(id);


--
-- Name: fk_rails_fa0cd92a53; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY remarks
    ADD CONSTRAINT fk_rails_fa0cd92a53 FOREIGN KEY (work_order_id) REFERENCES work_orders(id);


--
-- PostgreSQL database dump complete
--

